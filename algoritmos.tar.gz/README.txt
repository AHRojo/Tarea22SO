Andres Huerta Rojo 201473544-8

Instrucciones de compilacion
-Para compilar el programa se debe viajar a traves de la terminal de ubuntu utilizando el comando "cd _NombredelArchivo_"
-Una vez dentro de la dirección del archivo main.c ejecutar el siguiente comando "make".
-Para ejecutar el programa ingresar el comando ./programa.

Es importante tener en cuenta que el programa no creara un archivo de texto, por ello dentro de la carpeta donde este guardado el ejecutable, makefile y codigo fuente
debe estar el archivo llamado texto.txt.
